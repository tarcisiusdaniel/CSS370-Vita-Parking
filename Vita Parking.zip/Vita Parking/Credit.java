package Customer;

import java.util.*;

public class Credit extends PaymentImpl
{
    Credit(long cardNumber)
    {
        super(cardNumber);
    }
}