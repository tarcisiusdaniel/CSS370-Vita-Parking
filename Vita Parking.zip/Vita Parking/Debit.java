package Customer;

import java.util.*;

public class Debit extends PaymentImpl
{
    Debit(long cardNumber)
    {   
        super(cardNumber);
    }
}