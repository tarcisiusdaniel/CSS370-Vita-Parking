package Customer;

import java.util.*;

public interface PaymentInfo
{
    public long getCardNumber();
    public void setCardNumber(long newCardNumber);
    public String toString();
}